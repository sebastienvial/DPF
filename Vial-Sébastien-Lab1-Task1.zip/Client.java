
public class Client {

	public static void main(String[] args) {
		Fruit fruit1 = new Fruit();
		fruit1.setNom("pomme");
		fruit1.setPepin(true);
		
		Fruit fruit2 = new Fruit();
		fruit2.setNom("fraise");
		fruit2.setPepin(false);
		
		fruit1.afficherFruit();
		fruit2.afficherFruit();
		
	}

}
