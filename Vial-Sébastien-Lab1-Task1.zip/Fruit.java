
public class Fruit {
	
	private String nom;
	private Boolean pepin;
	
	public Fruit() {
		
	}

	public Fruit(String nom, Boolean pepin) {
		super();
		this.nom = nom;
		this.pepin = pepin;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public Boolean getPepin() {
		return pepin;
	}

	public void setPepin(Boolean pepin) {
		this.pepin = pepin;
	}
	
	
	public void afficherFruit() {
		System.out.println("Fruit [nom=" + nom + ", pepin=" + pepin + "]");		
	}

	 

}
