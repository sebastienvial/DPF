import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

public class PanierFruit implements Contenu {
	
	private boolean pepin = false;
	
	private ArrayList<Fruit> lstFruits;
	
	public PanierFruit() {
		lstFruits = new ArrayList<Fruit>();
	}
	
	public void ajouter(Fruit fruit) {
		lstFruits.add(fruit);
		if (fruit.getPepin())
			this.pepin = true;
	}
	
	public void supprimer(Fruit fruit) {
		lstFruits.remove(fruit);
	}
	
	public Iterator getChildren() {
		return lstFruits.iterator();
	}

	@Override
	public void afficherFruit() {
		// TODO Auto-generated method stub
		String affichage = "Panier (";
		
		for (Iterator i = lstFruits.iterator(); i.hasNext(); ) {
			Fruit fruit = (Fruit) i.next();
			affichage += fruit.getNom() + " " ;			
		}

		affichage = affichage.trim() + ")";
		System.out.print(affichage);		
	}

}
