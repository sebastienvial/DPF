
public interface Contenu {
	
	public void afficherFruit();

}
