
abstract class FruitCalorie {
	
	abstract public int calculCalories(String nom);	
	
}